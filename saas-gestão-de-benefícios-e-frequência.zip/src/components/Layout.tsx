import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Users, FileText, CalendarCheck, DollarSign, LogOut } from 'lucide-react';

export default function Layout() {
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    console.log('[Layout] Executando logout da aplicação');
    // Mudar para /login simulando logoff
    navigate('/login');
  };

  const navItems = [
    { name: 'Funcionários', path: '/app/employees', icon: Users },
    { name: 'Motor de Regras', path: '/app/terms', icon: FileText },
    { name: 'Frequência', path: '/app/attendance', icon: CalendarCheck },
    { name: 'Fechamento Financeiro', path: '/app/financial', icon: DollarSign },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-6 border-b border-gray-200">
          <h1 className="text-xl font-bold tracking-tight text-blue-600">RH Benefits</h1>
          <p className="text-xs text-gray-500 mt-1">Gestão de VR/VT</p>
        </div>
        
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map((item) => {
            const isActive = location.pathname.startsWith(item.path);
            const Icon = item.icon;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                  isActive 
                    ? 'bg-blue-50 text-blue-700' 
                    : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'
                }`}
                onClick={() => console.log(`[Layout] Navegando para ${item.path}`)}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'text-blue-600' : 'text-gray-400'}`} />
                {item.name}
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-gray-200">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-3 py-2.5 w-full rounded-md text-sm font-medium text-gray-700 hover:bg-red-50 hover:text-red-700 transition-colors"
          >
            <LogOut className="w-5 h-5 text-gray-400 group-hover:text-red-700" />
            Sair do Sistema
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}
