import { useState, useEffect } from 'react';
import { Funcionario, Termo } from '../types';
import { dummyFuncionarios, dummyTermos } from '../lib/dummy-data';
import { getDaysInMonth, format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function Attendance() {
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>([]);
  const [termos, setTermos] = useState<Termo[]>([]);
  
  // Controle de filtro mes/ano e quinzena
  const [selectedDate, setSelectedDate] = useState(() => format(new Date(), 'yyyy-MM'));
  const [quinzena, setQuinzena] = useState<1 | 2>(1);
  
  // State complexo da grid: funcionario_id -> (dia -> termo_id)
  const [gridData, setGridData] = useState<Record<string, Record<string, string>>>(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('rh_grid_data') || '{}');
      return saved[selectedDate] || {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('rh_grid_data') || '{}');
      setGridData(saved[selectedDate] || {});
    } catch {
      setGridData({});
    }
  }, [selectedDate]);

  const [yearStr, monthStr] = selectedDate.split('-');
  const currentYear = parseInt(yearStr, 10);
  const currentMonth = parseInt(monthStr, 10) - 1;

  const daysInMonth = getDaysInMonth(new Date(currentYear, currentMonth));
  const startDay = quinzena === 1 ? 1 : 16;
  const endDay = quinzena === 1 ? 15 : daysInMonth;
  const daysArray = Array.from({ length: endDay - startDay + 1 }, (_, i) => startDay + i);

  useEffect(() => {
    console.log(`[Attendance Grid] Carregando dicionario de funcionários e termos para ${selectedDate}`);
    setFuncionarios(dummyFuncionarios);
    setTermos(dummyTermos);
  }, []);

  const handleCellChange = (funcId: string, day: number, termoId: string) => {
    console.log(`[Attendance Grid] Atualizando celula - Func: ${funcId}, Dia: ${day}, Termo: ${termoId}`);
    
    setGridData(prev => {
      const nextFuncData = { ...(prev[funcId] || {}) };
      if (termoId) {
        nextFuncData[day.toString()] = termoId;
      } else {
        delete nextFuncData[day.toString()];
      }
      const newData = { ...prev, [funcId]: nextFuncData };
      
      try {
        const saved = JSON.parse(localStorage.getItem('rh_grid_data') || '{}');
        saved[selectedDate] = newData;
        localStorage.setItem('rh_grid_data', JSON.stringify(saved));
      } catch (e) {
        console.error('Erro ao salvar no localStorage', e);
      }
      
      return newData;
    });
  };

  const getSiglaFromTermoId = (id: string) => {
    return termos.find(t => t.id === id)?.sigla || '';
  };

  return (
    <div className="p-8 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-gray-900">Painel Operacional Diario</h2>
          <p className="text-sm text-gray-500 mt-1">Apenas clique nas células para aplicar um termo nos dias ausentes/extras.</p>
        </div>
        <div className="flex items-center gap-4 mt-4 md:mt-0">
          <div>
            <label className="sr-only">Mês/Ano</label>
            <input 
              type="month" 
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-1.5 text-sm focus:ring-blue-500 focus:border-blue-500 bg-white"
            />
          </div>
          <div className="flex bg-gray-100 p-1 rounded-md border border-gray-200">
            <button
              onClick={() => setQuinzena(1)}
              className={`px-3 py-1.5 text-sm font-medium rounded ${quinzena === 1 ? 'bg-white text-blue-700 shadow-sm transition' : 'text-gray-600 hover:text-gray-900 transition'}`}
            >
              1ª Quinzena (1-15)
            </button>
            <button
              onClick={() => setQuinzena(2)}
              className={`px-3 py-1.5 text-sm font-medium rounded ${quinzena === 2 ? 'bg-white text-blue-700 shadow-sm transition' : 'text-gray-600 hover:text-gray-900 transition'}`}
            >
              2ª Quinzena (16-Fim)
            </button>
          </div>
          <div className="bg-blue-100 text-blue-800 px-4 py-2 rounded-md font-semibold hidden md:block">
            {format(new Date(currentYear, currentMonth), 'MMMM / yyyy', { locale: ptBR }).toUpperCase()}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left whitespace-nowrap">
            <thead className="bg-gray-800 text-white">
              <tr>
                <th className="px-4 py-3 font-medium sticky left-0 z-10 bg-gray-900 border-r border-gray-700 min-w-64">
                  Colaborador
                </th>
                {daysArray.map(day => (
                  <th key={day} className="px-2 py-3 text-center border-r border-gray-700 min-w-16">
                    <div className="text-xs text-gray-400">{format(new Date(currentYear, currentMonth, day), 'EEEE', { locale: ptBR }).charAt(0).toUpperCase()}</div>
                    <div>{day}</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {funcionarios.map(f => (
                <tr key={f.id} className="hover:bg-blue-50 group">
                  <td className="px-4 py-3 sticky left-0 z-10 bg-white group-hover:bg-blue-50 border-r border-gray-200">
                    <div className="font-semibold text-gray-900">{f.nome}</div>
                    <div className="text-xs text-gray-500 overflow-hidden text-ellipsis">{f.empresa} - {f.setor}</div>
                  </td>
                  
                  {daysArray.map(day => {
                    const currentTermoId = gridData[f.id]?.[day.toString()] || '';
                    
                    return (
                      <td key={day} className="px-1 py-1 border-r border-gray-200 p-0 text-center relative">
                        <select
                          value={currentTermoId}
                          onChange={(e) => handleCellChange(f.id, day, e.target.value)}
                          className={`w-full h-10 text-center font-bold appearance-none cursor-pointer border-transparent hover:border-blue-400 focus:border-blue-500 rounded focus:ring-0 ${
                            currentTermoId ? 'bg-blue-100 text-blue-900' : 'bg-transparent text-gray-400'
                          }`}
                          title={`Dia ${day} - ${f.nome}`}
                        >
                          <option value="">-</option>
                          {termos.map(t => (
                            <option key={t.id} value={t.id}>{t.sigla}</option>
                          ))}
                        </select>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      <div className="text-sm text-gray-500 italic">
        * Células vazias ('-') não geram descontos nem acréscimos. Serão contabilizadas como dias trabalhados padrão pelo sistema se for dia útil, conforme layout da empresa.
      </div>
    </div>
  );
}
