import { useState, useEffect } from 'react';
import { Funcionario, Termo } from '../types';
import { dummyFuncionarios, dummyTermos } from '../lib/dummy-data';
import { getDaysInMonth, isWeekend, format } from 'date-fns';
import { Info } from 'lucide-react';

type CalculoFinanceiro = {
  funcionario: Funcionario;
  vrAntecipado: number;
  vtAntecipado: number;
  vrDevido: number;
  vtDevido: number;
  saldoVr: number;
  saldoVt: number;
  vrProxima: number;
  vtProxima: number;
  vrSugerido: number;
  vtSugerido: number;
  vrMotivos: string[];
  vtMotivos: string[];
};

export default function Financial() {
  const [calculos, setCalculos] = useState<CalculoFinanceiro[]>([]);
  const [quinzena, setQuinzena] = useState<1 | 2>(1);
  const [selectedDate, setSelectedDate] = useState(() => format(new Date(), 'yyyy-MM'));
  const [valoresPagos, setValoresPagos] = useState<Record<string, { vr: string, vt: string }>>({});

  const handleValorPagoChange = (id: string, type: 'vr' | 'vt', value: string) => {
    setValoresPagos(prev => ({
      ...prev,
      [id]: {
        ...(prev[id] || { vr: '', vt: '' }),
        [type]: value
      }
    }));
  };

  useEffect(() => {
    console.log(`[Financial] Inicializando motor de cálculo de fechamento para ${selectedDate} - ${quinzena}ª quinzena`);
    
    const [yearStr, monthStr] = selectedDate.split('-');
    const currentYear = parseInt(yearStr, 10);
    const currentMonth = parseInt(monthStr, 10) - 1;
    const daysInMonth = getDaysInMonth(new Date(currentYear, currentMonth));
    
    const startDay = quinzena === 1 ? 1 : 16;
    const endDay = quinzena === 1 ? 15 : daysInMonth;

    let diasUteisAtual = 0;
    for (let day = startDay; day <= endDay; day++) {
      const date = new Date(currentYear, currentMonth, day);
      if (!isWeekend(date)) diasUteisAtual++;
    }

    // Calcula dias úteis da próxima quinzena
    let nextYear = currentYear;
    let nextMonth = currentMonth;
    let proxQuinzena = quinzena === 1 ? 2 : 1;
    if (proxQuinzena === 1) {
        nextMonth++;
        if (nextMonth > 11) {
            nextMonth = 0;
            nextYear++;
        }
    }
    const daysInNextMonth = getDaysInMonth(new Date(nextYear, nextMonth));
    const nextStartDay = proxQuinzena === 1 ? 1 : 16;
    const nextEndDay = proxQuinzena === 1 ? 15 : daysInNextMonth;

    let diasUteisProxima = 0;
    for (let day = nextStartDay; day <= nextEndDay; day++) {
        const date = new Date(nextYear, nextMonth, day);
        if (!isWeekend(date)) diasUteisProxima++;
    }

    let savedGrid: Record<string, Record<string, string>> = {};
    try {
        const fullSave = JSON.parse(localStorage.getItem('rh_grid_data') || '{}');
        savedGrid = fullSave[selectedDate] || {};
    } catch(e) {}

    const calculosSimulados = dummyFuncionarios.map(func => {
      let vrDevidoCalculado = 0;
      let vtDevidoCalculado = 0;
      const vrMotivos: string[] = [];
      const vtMotivos: string[] = [];

      const funcGrid = savedGrid[func.id] || {};

      for (let day = startDay; day <= endDay; day++) {
        const date = new Date(currentYear, currentMonth, day);
        const isFds = isWeekend(date);
        const termoId = funcGrid[day.toString()];
        const termo = dummyTermos.find(t => t.id === termoId);

        if (!isFds && !termo) {
            vrDevidoCalculado += func.vr_diario;
            vtDevidoCalculado += func.vt_diario;
        } else if (termo) {
           // VR Logic
           if (termo.acao_vr === 'PAGA') vrDevidoCalculado += func.vr_diario;
           else if (termo.acao_vr === 'EXTRA') {
               vrDevidoCalculado += func.vr_diario;
               vrMotivos.push(`Dia ${day}: ${termo.descricao} (+R$ ${func.vr_diario.toFixed(2)})`);
           }
           else if (termo.acao_vr === 'DESCONTA') {
               vrMotivos.push(`Dia ${day}: ${termo.descricao} (-R$ ${func.vr_diario.toFixed(2)})`);
           }

           // VT Logic
           if (termo.acao_vt === 'PAGA') vtDevidoCalculado += func.vt_diario;
           else if (termo.acao_vt === 'EXTRA') {
               vtDevidoCalculado += func.vt_diario;
               vtMotivos.push(`Dia ${day}: ${termo.descricao} (+R$ ${func.vt_diario.toFixed(2)})`);
           }
           else if (termo.acao_vt === 'DESCONTA') {
               vtMotivos.push(`Dia ${day}: ${termo.descricao} (-R$ ${func.vt_diario.toFixed(2)})`);
           }
        }
      }

      const vrAntecipado = func.vr_diario * diasUteisAtual;
      const vtAntecipado = func.vt_diario * diasUteisAtual;

      const saldoVr = vrDevidoCalculado - vrAntecipado;
      const saldoVt = vtDevidoCalculado - vtAntecipado;

      const vrProxima = func.vr_diario * diasUteisProxima;
      const vtProxima = func.vt_diario * diasUteisProxima;
      
      const vrSugerido = vrProxima + saldoVr;
      const vtSugerido = vtProxima + saldoVt;

      // Mock de tooltips iniciais para teste, se nada foi alterado no painel operacional
      if (Object.keys(savedGrid).length === 0) {
         if (func.nome.includes('João')) {
           vrMotivos.push("Simulação: 1 Falta Injustificada (-R$ 35.00)");
           vtMotivos.push("Simulação: 1 Falta Injustificada (-R$ 12.50)");
         } else if (func.nome.includes('Carlos')) {
           vrMotivos.push("Simulação: 1 Plantão Extra (+R$ 40.00)");
           vtMotivos.push("Simulação: 1 Plantão Extra (+R$ 15.00)");
         }
      }

      return {
        funcionario: func,
        vrAntecipado,
        vtAntecipado,
        vrDevido: vrDevidoCalculado,
        vtDevido: vtDevidoCalculado,
        saldoVr,
        saldoVt,
        vrProxima,
        vtProxima,
        vrSugerido,
        vtSugerido,
        vrMotivos,
        vtMotivos
      };
    });

    console.log('[Financial] Cálculos efetuados com sucesso:', calculosSimulados);
    setCalculos(calculosSimulados);
  }, [quinzena, selectedDate]);

  const renderTooltip = (motivos: string[]) => {
    if (motivos.length === 0) return null;
    return (
      <div className="group relative inline-flex items-center justify-center">
        <Info className="w-4 h-4 text-gray-400 ml-1 cursor-help hover:text-blue-500" />
        <div className="absolute bottom-full right-0 md:left-1/2 md:-translate-x-1/2 mb-2 w-max max-w-[200px] sm:max-w-xs bg-gray-900 text-white text-xs rounded-md py-1.5 px-3 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50 shadow-lg">
          <ul className="text-left list-disc pl-3">
            {motivos.map((m, i) => <li key={i}>{m}</li>)}
          </ul>
          <div className="absolute top-full right-2 md:left-1/2 md:-translate-x-1/2 border-4 border-transparent border-t-gray-900"></div>
        </div>
      </div>
    );
  };

  return (
    <div className="p-8 max-w-[1400px] mx-auto space-y-8">
      <div className="flex flex-col md:flex-row md:items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-gray-900">Demonstrativo Financeiro</h2>
          <p className="text-sm text-gray-500 mt-1">Comparativo entre valor padrão antecipado e valor devido para a quinzena.</p>
        </div>
        <div className="flex flex-col sm:flex-row items-end sm:items-center gap-4 mt-4 md:mt-0">
          <div>
            <label className="sr-only">Mês/Ano</label>
            <input 
              type="month" 
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-1.5 text-sm focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div className="flex bg-gray-100 p-1 rounded-md border border-gray-200">
            <button
              onClick={() => setQuinzena(1)}
              className={`px-3 py-1.5 text-sm font-medium rounded ${quinzena === 1 ? 'bg-white text-blue-700 shadow-sm transition' : 'text-gray-600 hover:text-gray-900 transition'}`}
            >
              1ª Quinzena
            </button>
            <button
              onClick={() => setQuinzena(2)}
              className={`px-3 py-1.5 text-sm font-medium rounded ${quinzena === 2 ? 'bg-white text-blue-700 shadow-sm transition' : 'text-gray-600 hover:text-gray-900 transition'}`}
            >
              2ª Quinzena
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-x-auto">
        <table className="w-full text-sm text-left min-w-[1000px]">
          <thead className="bg-gray-50 text-gray-600 border-b border-gray-200 uppercase text-xs">
            <tr>
              <th className="px-4 py-3 font-semibold" rowSpan={2}>Colaborador / Empresa</th>
              <th className="px-4 py-2 font-semibold text-center border-b border-gray-200" colSpan={4}>Vale Refeição (VR)</th>
              <th className="px-4 py-2 font-semibold text-center border-b border-gray-200 border-l" colSpan={4}>Vale Transporte (VT)</th>
            </tr>
            <tr className="bg-gray-50">
              <th className="px-4 py-2 font-semibold text-right">Antecipado</th>
              <th className="px-4 py-2 font-semibold text-right">Devido (Real)</th>
              <th className="px-4 py-2 font-semibold text-right">Ajuste</th>
              <th className="px-4 py-2 font-semibold text-right bg-blue-50 text-blue-800">A Pagar (Sugestão)</th>
              <th className="px-4 py-2 font-semibold text-center">Valor Pago</th>
              <th className="px-4 py-2 font-semibold text-right border-l">Antecipado</th>
              <th className="px-4 py-2 font-semibold text-right">Devido (Real)</th>
              <th className="px-4 py-2 font-semibold text-right">Ajuste</th>
              <th className="px-4 py-2 font-semibold text-right bg-blue-50 text-blue-800">A Pagar (Sugestão)</th>
              <th className="px-4 py-2 font-semibold text-center">Valor Pago</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {calculos.map(({ funcionario, vrAntecipado, vrDevido, saldoVr, vtAntecipado, vtDevido, saldoVt, vrSugerido, vtSugerido, vrMotivos, vtMotivos }) => (
              <tr key={funcionario.id} className="hover:bg-gray-50 bg-white">
                <td className="px-4 py-3">
                  <div className="font-bold text-gray-900">{funcionario.nome}</div>
                  <div className="text-xs text-gray-500">{funcionario.empresa} - {funcionario.setor}</div>
                </td>
                
                <td className="px-4 py-3 text-right text-gray-500">R$ {vrAntecipado.toFixed(2)}</td>
                <td className="px-4 py-3 text-right font-medium">R$ {vrDevido.toFixed(2)}</td>
                <td className={`px-4 py-3 text-right text-xs font-semibold ${saldoVr > 0 ? 'text-green-600' : saldoVr < 0 ? 'text-red-600' : 'text-gray-400'}`}>
                  {saldoVr > 0 ? `+ R$ ${saldoVr.toFixed(2)}` : saldoVr < 0 ? `- R$ ${Math.abs(saldoVr).toFixed(2)}` : 'R$ 0.00'}
                </td>
                <td className={`px-4 py-3 text-right font-bold bg-blue-50/50 ${vrSugerido < 0 ? 'text-red-600' : 'text-blue-700'}`}>
                  <div className="flex justify-end items-center">
                    R$ {vrSugerido.toFixed(2)}
                    {renderTooltip(vrMotivos)}
                  </div>
                </td>
                <td className="px-4 py-3 text-center">
                  <div className="flex items-center justify-center">
                    <span className="text-gray-500 mr-1 text-xs">R$</span>
                    <input 
                      type="number" 
                      step="0.01"
                      className="w-24 px-2 py-1 text-right border border-gray-300 rounded focus:ring-blue-500 focus:border-blue-500"
                      placeholder="0.00"
                      value={valoresPagos[funcionario.id]?.vr || ''}
                      onChange={(e) => handleValorPagoChange(funcionario.id, 'vr', e.target.value)}
                    />
                  </div>
                </td>
                
                <td className="px-4 py-3 text-right border-l text-gray-500">R$ {vtAntecipado.toFixed(2)}</td>
                <td className="px-4 py-3 text-right font-medium">R$ {vtDevido.toFixed(2)}</td>
                <td className={`px-4 py-3 text-right text-xs font-semibold ${saldoVt > 0 ? 'text-green-600' : saldoVt < 0 ? 'text-red-600' : 'text-gray-400'}`}>
                  {saldoVt > 0 ? `+ R$ ${saldoVt.toFixed(2)}` : saldoVt < 0 ? `- R$ ${Math.abs(saldoVt).toFixed(2)}` : 'R$ 0.00'}
                </td>
                <td className={`px-4 py-3 text-right font-bold bg-blue-50/50 ${vtSugerido < 0 ? 'text-red-600' : 'text-blue-700'}`}>
                  <div className="flex justify-end items-center">
                    R$ {vtSugerido.toFixed(2)}
                    {renderTooltip(vtMotivos)}
                  </div>
                </td>
                <td className="px-4 py-3 text-center">
                  <div className="flex items-center justify-center">
                    <span className="text-gray-500 mr-1 text-xs">R$</span>
                    <input 
                      type="number" 
                      step="0.01"
                      className="w-24 px-2 py-1 text-right border border-gray-300 rounded focus:ring-blue-500 focus:border-blue-500"
                      placeholder="0.00"
                      value={valoresPagos[funcionario.id]?.vt || ''}
                      onChange={(e) => handleValorPagoChange(funcionario.id, 'vt', e.target.value)}
                    />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
